-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-09-2024 a las 19:42:07
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `nequii`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personas en guia`
--

CREATE TABLE IF NOT EXISTS `personas en guia` (
  `ID` int(9) NOT NULL AUTO_INCREMENT,
  `Nombre` char(35) NOT NULL,
  `Apellidos` char(36) NOT NULL,
  `Fecha_Nacimiento` time NOT NULL,
  `Tipo_Documento` time NOT NULL,
  `Documento` char(26) NOT NULL,
  `Celular` char(16) NOT NULL,
  `Correo` int(65) NOT NULL,
  `Estrato` int(11) NOT NULL,
  `Direccion_Reccidencia` char(95) NOT NULL,
  `Edad` char(3) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla de venta`
--

CREATE TABLE IF NOT EXISTS `tabla de venta` (
  `ID` int(9) NOT NULL AUTO_INCREMENT,
  `Fecha_sys` datetime NOT NULL,
  `Documento` int(14) NOT NULL,
  `Valor` int(6) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transfererencia`
--

CREATE TABLE IF NOT EXISTS `transfererencia` (
  `ID` int(9) NOT NULL AUTO_INCREMENT,
  `Fecha_sys` datetime NOT NULL,
  `num_origen` char(13) NOT NULL,
  `num_destino` char(13) NOT NULL,
  `valor` int(8) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
